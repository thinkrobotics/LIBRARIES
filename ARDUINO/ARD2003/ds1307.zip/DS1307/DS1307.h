/* FILE:    DS1307.h

DATE:    10/05/2020
VERSION: 1.0

AUTHORS Cordier Yves (V1.0)

10/05/2020 : V1.0


Library header Real Time Clock library DS1307.

This library has been, when possible, writen with the same name of function as RTC library for SAM processor

All the functions about alarm could not be implemented because the DS1307 function as a slave 
of the arduino and communicate by i2c protocol

Somes function have been added run stop, and function for the control of the square wave pin


*/


#ifndef DS1307_h
#define DS1307_h

#include "Arduino.h"
#include "Wire.h"

// Standard define
#define _adressDS1307 (0x68) // hardware adress of DS1307
// Commands words for output on frequency generator
#define _freq1Hz (0x10)		// 1Hz output on SQW pin
#define _freq4096Hz (0x11)	// 4.096 kHz output on SQW pin
#define _freq8192Hz (0x12)	// 8.192 kHz output on SQW pin
#define _freq32768Hz (0x13)	// 32.768 kHz output on SQW pin
#define _freq0out1 (0x80)	// pin set to 1
#define _freq0out0 (0x00)	// pin set to 0

#define _delaiBetweenTwoCallsForUpdatingDS1307Library (250) // 250 ms delay between two updates

// class definition
// ****************
class DS1307
{
	private :
	unsigned long lastCallRead =0;
	byte _RTCSecs=0;
	byte _RTCMins=0;
	byte _RTCHours=0;
	byte _RTCWeekday=7; // compute from date the 01/01/2000 was a Saturday
	byte _RTCDate=1; // 01
	byte _RTCMonth=1; // January
	byte _RTCYear=0; // 2000
	boolean _Run=false;
public:
	// constructors
	DS1307(boolean runPositionInitial=true); // set to run by default

	/* DS1307 RTC read and write functions */
	// similar as RTC library
	
	void begin (boolean reset=false);
	void setHours(byte h);
	void setMinutes(byte m);
	void setSeconds(byte s);
	void setYear(byte y);
	void setMonth(byte mo);
	void setDay(byte d);
	void setTime(byte h, byte m, byte s);
	void setDate(byte d, byte m, byte y);


	byte getYear();
	byte getMonth();
	byte getDay();
	byte getHours();
	byte getMinutes();
	byte getSeconds();
	byte getWeekday();

	// Specific to this library
	// date and time function
	String getTimeString();
	String getDateString();
	void RTCWrite( byte Year, byte Month, byte Day, byte hour, byte Minuite, byte Second);  
	
	// sqare wave pin function
	void stop();
	void run();
	void squareWave(byte freq); // see the defines for frequency

	

private:
	void RTCRead(); 
	byte BCD2DEC(byte BCDValue);
	byte DEC2BCD(byte DECValue);
	unsigned long delaiEntre(unsigned long T1, unsigned long T2);
	void update(boolean modeForce=false);
	byte dayOfWeek(byte Day, byte Month, byte Year );
};
#endif