/* FILE:    DS1307.cpp

DATE:    10/05/2020
VERSION: 1.0

AUTHORS Cordier Yves (V0.3)

10/05/2020 : V1.0


Library header Real Time Clock library DS1307.

This library has been, when possible, writen with the same name of function as RTC library for SAM processor

All the functions about alarm could not be implemented because the DS1307 function as a slave 
of the arduino and communicate by i2c protocol

Somes function have been added run stop, and function for the control of the square wave pin


*/

#include "DS1307.h"

/* Constructor to initiliase the I2C library */
DS1307::DS1307(boolean runPositionInitial) 
{ 
	_Run=runPositionInitial;
}
/* Library function to initialise the I2C library */
void DS1307::begin(boolean reset)
{
	Wire.begin();
	// start all the process of time scheduled 
	lastCallRead=millis();
	if (reset) RTCWrite( _RTCYear, _RTCMonth, _RTCDate, _RTCHours, _RTCMins, _RTCSecs);
	else 
	{
		update(true); // force load values from DS1307
		if (_Run) run(); else stop(); // set mode of function of DS1307		
	}
}
/* Library function to return year byte of last RTC read */
byte DS1307::getYear()
{
	update();
	return _RTCYear;
}

/* Library function to return month byte of last RTC read */
byte DS1307::getMonth()
{
	update();
	return _RTCMonth;
}

/* Library function to return day byte of last RTC read */
byte DS1307::getDay()
{
	update();
	return _RTCDate;
}

/* Library function to return hour byte of last RTC read */
byte DS1307::getHours()
{
	update();
	return _RTCHours;
}

/* Library function to return minute byte of last RTC read */
byte DS1307::getMinutes()
{
	update();
	return _RTCMins;
}

/* Library function to return second byte of last RTC read */
byte DS1307::getSeconds()
{
	update();
	return _RTCSecs;
}

/* Library function to return day of week byte of last RTC read */
byte DS1307::getWeekday()
{
	update();
	return _RTCWeekday;
}

/* Library function to return current time as a string */
String DS1307::getTimeString()
{
	char TimeString[] = "00:00:00";
	update(); 
	TimeString[0] = (_RTCHours / 10)+48;
	TimeString[1] = (_RTCHours % 10)+48;  
	TimeString[3] = (_RTCMins / 10)+48;
	TimeString[4] = (_RTCMins % 10)+48; 
	TimeString[6] = (_RTCSecs / 10)+48;
	TimeString[7] = (_RTCSecs % 10)+48;

	return TimeString;
}

/* Library function to return current date as a string */
String DS1307::getDateString()
{
	char DateString[] = "00/00/00";
	update(); 

	DateString[6] = (_RTCYear / 10)+48;
	DateString[7] = (_RTCYear % 10)+48;  
	DateString[3] = (_RTCMonth / 10)+48;
	DateString[4] = (_RTCMonth % 10)+48; 
	DateString[0] = (_RTCDate / 10)+48;
	DateString[1] = (_RTCDate % 10)+48;

	return DateString;
}

/* Library private function to read current time and date from the RTC module */

void DS1307::RTCRead()
{
	Wire.beginTransmission(_adressDS1307);
	Wire.write(0);
	Wire.endTransmission();
	
	Wire.requestFrom(_adressDS1307, 7);
	byte data=Wire.read();
	_RTCSecs = BCD2DEC(data & 0x7f);
	_Run=((data & 0x80)==0);
	_RTCMins = BCD2DEC(Wire.read());
	_RTCHours = BCD2DEC(Wire.read() & 0x7f);
	_RTCWeekday  = Wire.read();
	_RTCDate = BCD2DEC(Wire.read());
	_RTCMonth = BCD2DEC(Wire.read());
	_RTCYear = BCD2DEC(Wire.read());
}

/* Library function to write current time and date from the RTC module */
void DS1307::RTCWrite( byte Year, byte Month, byte Day, byte Hour, byte Minute, byte Second)
{
	int jourDeSemaine=dayOfWeek(Day,Month,Year);
	
	Wire.beginTransmission(_adressDS1307);
	Wire.write(0);
	if (_Run) 
	{
		Wire.write(DEC2BCD(Second) & 0x7f);  // bit N° 7 set to 0
	}
	else 
	{
		Wire.write((DEC2BCD(Second) & 0x7f) | 0x80); // bit N° 7 set to 1
	}
	Wire.write(DEC2BCD(Minute));
	Wire.write(DEC2BCD(Hour));    
	Wire.write(DEC2BCD(byte(jourDeSemaine)));
	Wire.write(DEC2BCD(Day));
	Wire.write(DEC2BCD(Month));
	Wire.write(DEC2BCD(Year));
	Wire.endTransmission();
	// read back the local time
	lastCallRead=millis();
	RTCRead();
}

/* Library function to write current time to the RTC module */
void DS1307::setTime(byte h, byte m, byte s)
{
	Wire.beginTransmission(_adressDS1307);
	Wire.write(0);
	if (_Run) 
	{
		Wire.write(DEC2BCD(s) & 0x7f); 
	}
	else 
	{
		Wire.write((DEC2BCD(s) & 0x7f) | 0x80);
	}
	Wire.write(DEC2BCD(m));
	Wire.write(DEC2BCD(h));    
	Wire.endTransmission();

	// read back the local time
	lastCallRead=millis();
	RTCRead();
}

/* Library function to write current date to the RTC module */
void DS1307::setDate(byte d, byte m, byte y )
{
	Wire.beginTransmission(_adressDS1307);
	Wire.write(3);  
	int jourDeSemaine=dayOfWeek(d,m,y);
	Wire.write(DEC2BCD(jourDeSemaine));
	Wire.write(DEC2BCD(d));
	Wire.write(DEC2BCD(m));
	Wire.write(DEC2BCD(y));
	Wire.endTransmission();

	// read back the local time
	lastCallRead=millis();
	RTCRead();
}

/* Library function to write current second to the RTC module */
void DS1307::setSeconds(byte s)
{
	Wire.beginTransmission(_adressDS1307);
	Wire.write(0);
	if (_Run) 
	{
		Wire.write(DEC2BCD(s) & 0x7f); 
	}
	else 
	{
		Wire.write((DEC2BCD(s) & 0x7f) | 0x80);
	}
	Wire.endTransmission(); 
	// read back the local time
	lastCallRead=millis();
	RTCRead();
}

/* Library function to write current minutes to the RTC module */
void DS1307::setMinutes(byte m)
{
	Wire.beginTransmission(_adressDS1307);
	Wire.write(1);
	Wire.write(DEC2BCD(m));
	Wire.endTransmission();

	// read back the local time
	lastCallRead=millis();
	RTCRead();
}

/* Library function to write current hours to the RTC module */
void DS1307::setHours(byte h)
{
	Wire.beginTransmission(_adressDS1307);
	Wire.write(2);
	Wire.write(DEC2BCD(h));    
	Wire.endTransmission();

	// read back the local time
	lastCallRead=millis();
	RTCRead();
}

/* Library function to write current day to the RTC module */
void DS1307::setDay(byte d)
{
	Wire.beginTransmission(_adressDS1307);
	Wire.write(3);  
	int jourDeSemaine=dayOfWeek(d,_RTCMonth,_RTCYear);
	Wire.write(DEC2BCD(byte(jourDeSemaine)));
	Wire.write(DEC2BCD(d));
	Wire.endTransmission();
	// read back the local time
	lastCallRead=millis();
	RTCRead();
}

/* Library function to write current month to the RTC module */
void DS1307::setMonth(byte m)
{
	Wire.beginTransmission(_adressDS1307);
	Wire.write(3);  
	int jourDeSemaine=dayOfWeek(_RTCDate,m,_RTCYear);
	Wire.write(DEC2BCD(byte(jourDeSemaine)));
	Wire.endTransmission();
	Wire.beginTransmission(_adressDS1307);
	Wire.write(5);
	Wire.write(DEC2BCD(m));
	Wire.endTransmission();

	// read back the local time
	lastCallRead=millis();
	RTCRead();
}

/* Library function to write current year to the RTC module */
void DS1307::setYear(byte y)
{
	Wire.beginTransmission(_adressDS1307);
	Wire.write(3);  
	int jourDeSemaine=dayOfWeek(_RTCDate,_RTCMonth,y);
	Wire.write(DEC2BCD(byte(jourDeSemaine)));
	Wire.endTransmission();
	Wire.beginTransmission(_adressDS1307);
	Wire.write(6);
	Wire.write(DEC2BCD(y));
	Wire.endTransmission();

	// read back the local time
	lastCallRead=millis();
	RTCRead();
}

/* Private library function to convert BCD to decimal format */
byte DS1307::BCD2DEC(byte BCDValue)
{
	return ((BCDValue / 16) * 10) + (BCDValue & 0xF);
}

/* Private library function to convert decimal to BCD format */
byte DS1307::DEC2BCD(byte DECValue)
{
	return ((DECValue / 10) * 16) + (DECValue % 10);
}

/* private Library function to compute delay between two time */
unsigned long DS1307::delaiEntre(unsigned long T1, unsigned long T2)
{
	if (T2>T1) return (T2-T1);
	return (4294967295ul-T1+T2);
}

/* private Library function to update values from RTC clock every 500 ms at least*/
void DS1307::update(boolean modeForce=false)
{
	
	if (_Run || modeForce)
	{
		if (modeForce || (delaiEntre(lastCallRead,millis())>_delaiBetweenTwoCallsForUpdatingDS1307Library))
		{
			lastCallRead=millis();
			RTCRead();
		}
	}
	else
	{
		lastCallRead=millis();
	}
	
	
}

/* library function to run / stop clock */
void DS1307::run()
{   
	Wire.beginTransmission(_adressDS1307);
	Wire.write(0); // adresse de base de lecture
	Wire.endTransmission();
	Wire.requestFrom(_adressDS1307, 1); // nombre de byte à lire
	byte data=Wire.read();
	Wire.endTransmission();
	if ((data & 0x80)!=0) // if stop mode in DS1307
	{
		Wire.beginTransmission(_adressDS1307);
		Wire.write(0);
		Wire.write(data & 0x7f ); // put it on run mode set bit N°7 to 0
		Wire.endTransmission();
		update(true);
	}
	_Run=true;
}

void DS1307::stop()
{   
	Wire.beginTransmission(_adressDS1307);
	Wire.write(0); // adresse de base de lecture
	Wire.endTransmission();
	Wire.requestFrom(_adressDS1307, 1); // nombre de byte à lire
	byte data=Wire.read();
	Wire.endTransmission();
	if ((data & 0x80)==0) // if run mode in DS1307
	{
		Wire.beginTransmission(_adressDS1307);
		Wire.write(0);
		Wire.write((data & 0x7f) | 0x80); // put it on stop bit n° 7 set to 1
		Wire.endTransmission();
		update(true);
	}
	_Run=false;
}

/* library function to generate square wave on pin number 7 */
// relies on using correct function predefined mask

void DS1307::squareWave(byte f)
{
	Wire.beginTransmission(_adressDS1307);
	Wire.write(0x07); // address 07
	Wire.write(f); // command byte
	Wire.endTransmission();
}

/* private library function to get day of the week 1 sunday 2 monday ... */
byte DS1307::dayOfWeek(byte Day, byte Month, byte Year )
{
	int jourDeSemaine=0;
	//  according Mike Keith's algorithm
	if (Month>=3) 
	{
		int z= Year+2000;
		return ((((23*int(Month))/9) + Day + 4 + int(Year)+2000 + (z/4) - (z/100) + (z/400) - 2 ) % 7)+1;
	}
	else
	{
		int z=Year+1999;
		return ((((23*int(Month))/9) + Day + 4 + int(Year)+2000 + (z/4) - (z/100)+ (z/400)) % 7)+1;
	}
}
