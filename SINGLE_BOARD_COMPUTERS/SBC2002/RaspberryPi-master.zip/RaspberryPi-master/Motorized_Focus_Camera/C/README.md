# Motorized_Focus_Camera
## Preparation
```bash
cd RaspberryPi/Motorized_Focus_Camera
```
```bash
chmod +x enable_i2c_vc.sh
```
```bash
./enable_i2c_vc.sh
```
```bash
sudo reboot
```
# Usage
```bash
cd RaspberryPi/Motorized_Focus_Camera/C
```
```bash 
make 
```
```bash 
./manualFocus
```



 

