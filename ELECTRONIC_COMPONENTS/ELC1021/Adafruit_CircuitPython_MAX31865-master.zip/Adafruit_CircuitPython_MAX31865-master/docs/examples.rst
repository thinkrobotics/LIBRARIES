Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/max31865_simpletest.py
    :caption: examples/max31865_simpletest.py
    :linenos:
