
.. If you created a package, create one automodule per module in the package.

.. automodule:: adafruit_max31865
   :members:
