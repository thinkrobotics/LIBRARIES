# Sources

- The l293d library was originally based on [this tutorial](https://business.tutsplus.com/tutorials/controlling-dc-motors-using-python-with-a-raspberry-pi--cms-20051) - The circuit diagrams in the docs are from there.
- Some helpful information about the driver chip can be found [here](http://www.rakeshmondal.info/L293D-Motor-Driver).
- You can buy L293D driver chips cheaply online - I bought a [pack of 5 on Amazon](https://www.amazon.co.uk/dp/B008KYMVVY)
