SparkFun MPL3115A2 Breakout Libraries
=================================

Libraries for use in different environments. 


Directory Contents
-------------------
* **/Arduino** - [Arduino IDE](http://www.arduino.cc/en/Main/Software) libraries


License Information
-------------------
This product is open source! 
The code is beerware; if you see me (or any other SparkFun employee) at the local, and you've found our code helpful, please buy us a round!
Please use, reuse, and modify these files as you see fit. Please maintain attribution to SparkFun Electronics and release anything derivative under the same license.

Distributed as-is; no warranty is given.

- Your friends at SparkFun.

MPL3115A2_Advance Example.ino was developed by Kris Winer.



BUILD INSTRUCTIONS: 

$git subtree add -P <DIRECTORY NAME> --squash <git repo URL> <ref>

$git subtree pull -P <DIRECTORY NAME> --squash <git repo URL> <ref>