This is example Arduino code that allows you to print the raw altitude and temperature values in meters. No libraries are needed and all the I2C communication is handeled using the built-in wire functions.   

[Creative Commons Attribution-ShareAlike](http://creativecommons.org/licenses/by-sa/3.0/)
