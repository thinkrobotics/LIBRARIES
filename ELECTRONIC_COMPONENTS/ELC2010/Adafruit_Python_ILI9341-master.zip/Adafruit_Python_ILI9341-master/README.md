This library has been archived and replaced by a new library that handles multiple displays:

https://github.com/adafruit/Adafruit_CircuitPython_RGB_Display

This library is no longer supported. Please use the new library
