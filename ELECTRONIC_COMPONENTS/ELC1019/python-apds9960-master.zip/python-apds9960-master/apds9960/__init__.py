from apds9960.device import APDS9960, uAPDS9960

__all__ = [ 'APDS9960', 'uAPDS9960', ]
