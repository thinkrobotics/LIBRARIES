# TB612FNG Motor Controller 
## Raspberry Pi Example
In this example we will drive the motors forward, reverse and left turn/right turn.

### Pinout
![Raspberry Pi Pinout](raspi-pinout-gh.jpg)


