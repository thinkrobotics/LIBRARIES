# Maker's Digest - TB6612FNG Dual H-Bridge Motor Controller
### How to connect the TB6612FNG Motor Controller to Arduino & Raspbery Pi

This repository is companion to the video below:

[![IMAGE ALT TEXT HERE](https://img.youtube.com/vi/3LBiyBTnt7g/0.jpg)](https://www.youtube.com/watch?v=3LBiyBTnt7g)

## [Arduino](/arduino)
The arduino code can be loaded into the arduino IDE by either downloading or cloning this repository and opening the .ino file in the arduino IDE.

## [Raspberry Pi](/raspberry-pi)
Often times the raspberry pi python examples require a library or module. Please see the README file in the raspberry-pi directory for detailed instructions. 
3LBiyBTnt7g
