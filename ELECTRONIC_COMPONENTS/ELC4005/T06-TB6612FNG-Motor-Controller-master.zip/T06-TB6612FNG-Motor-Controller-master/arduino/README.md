# TB6612FNG Motor Controller
## Arduino Exmaple code
In this example, we will drive the motors forward, reverse and left turn/right turn.

### Pinout
![Arduino Pinout](arduino-pinout-gh.jpg)

