Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/tca9548a_simpletest.py
    :caption: examples/tca9548a_simpletest.py
    :linenos:
