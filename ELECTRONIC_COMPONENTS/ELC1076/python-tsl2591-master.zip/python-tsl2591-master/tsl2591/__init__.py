
__version__ = '0.0.1'

from .read_tsl import Tsl2591